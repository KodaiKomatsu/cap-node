sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"],function(e){"use strict";return e.extend("cataloglist.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map